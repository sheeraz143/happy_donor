import "../css/BloodRequest.css";
import bloodGroupImg from "../assets/bloodimage.png";
import profPicImg from "../assets/profpic.png";
import { Link, useNavigate } from "react-router-dom";
import shareIcon from "../assets/Share.png";
import locationIcon from "../assets/mappoint.png";
import { useDispatch } from "react-redux";
import { donateBloods, setLoader } from "../redux/product";
import { toast } from "react-toastify";
import { useEffect, useState } from "react";

function Donate() {
  const [activeTab, setActiveTab] = useState("open");
  const [openRequests, setOpenRequests] = useState([]);
  const [closedRequests, setClosedRequests] = useState([]);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setLoader(true)); // Start loading
    try {
      dispatch(
        donateBloods(activeTab, (res) => {
          console.log("res: ", res);
          // setData(res?.user);
          if (res.errors) {
            toast.error(res.errors);
           } else {
            if (activeTab === "open") {
              setOpenRequests(
                res.requests.filter((req) => req.status === "Open")
              );
            } else {
              setClosedRequests(
                res.requests.filter((req) => req.status !== "Open")
              );
            }
          }
          dispatch(setLoader(false));
        })
      );
    } catch (error) {
      toast.error(error.message || "Error fetching requests");
      dispatch(setLoader(false));
    }
  }, [dispatch, activeTab]);

  // const openRequests = [
  //   {
  //     name: "sheeraz",
  //     hospital: "Mount Sinal Hospital",
  //     units: 2,
  //     date: "2024.07.16,05:30",
  //     profilePic: profPicImg,
  //     bloodGroupImage: bloodGroupImg,
  //   },
  //   {
  //     name: "john",
  //     hospital: "Mount Sinal Hospital",
  //     units: 2,
  //     date: "2024.07.16,05:30",
  //     profilePic: profPicImg,
  //     bloodGroupImage: bloodGroupImg,
  //   },
  //   {
  //     name: "smith",
  //     hospital: "Mount Sinal Hospital",
  //     units: 2,
  //     date: "2024.07.16,05:30",
  //     profilePic: profPicImg,
  //     bloodGroupImage: bloodGroupImg,
  //   },
  //   {
  //     name: "virat",
  //     hospital: "Mount Sinal Hospital",
  //     units: 2,
  //     date: "2024.07.16,05:30",
  //     profilePic: profPicImg,
  //     bloodGroupImage: bloodGroupImg,
  //   },
  // ];

  // const closedRequests = [
  //   {
  //     id: 1,
  //     name: "sheeraz",
  //     units: 2,
  //     date: "2024.07.16,05:30",
  //     Address: "Nehru Street, chennai",
  //     profilePic: profPicImg,
  //     bloodGroupImage: bloodGroupImg,
  //   },
  //   {
  //     id: 2,
  //     name: "john",
  //     Address: "Nehru Street, chennai",
  //     units: 2,
  //     date: "2024.07.16,05:30",
  //     profilePic: profPicImg,
  //     bloodGroupImage: bloodGroupImg,
  //   },
  // ];
  const handleCardClick = (request) => {
    navigate(`/request/${request?.id}`, { state: { request } });
  };

  // const renderRequestCard = (request, showAcceptButton) => (
  //   <div
  //     className="request-card"
  //     key={request.id}
  //     onClick={() => handleCardClick(request.id)}
  //   >
  //     <div className="request-header d-flex align-items-center">
  //       <div className="align-content-center">
  //         <img src={request.profilePic} alt="Profile" />
  //       </div>
  //       <div className="request-details ms-3">
  //         <div className="text-start fw-bold"> {request.name}</div>
  //         <div className="text-start"> {request.hospital}</div>
  //         <div className="text-start">Blood units: {request.units}</div>
  //         <div className="text-start"> {request.date}</div>
  //       </div>
  //       <div className="blood-group ms-auto">
  //         <img src={request.bloodGroupImage} alt="Blood Group" />
  //       </div>
  //     </div>

  //     <div className="accept-donar-button d-flex align-items-center mt-3">
  //       <div className="icon-container d-flex me-3">
  //         <Link to="#" className="share-link me-2">
  //           <img src={shareIcon} alt="Share" className="icon-img" />
  //         </Link>
  //         <Link to="#" className="location-link">
  //           <img src={locationIcon} alt="Location" className="icon-img" />
  //         </Link>
  //       </div>
  //       {showAcceptButton && (
  //         <button className="accepted-donors-btn btn btn-primary">
  //           Accept
  //         </button>
  //       )}
  //     </div>
  //   </div>
  // );

  // const renderOthersCard = (request) => (
  //   <div className="request-card" key={request.id}>
  //     <div className="request-header d-flex align-items-center">
  //       <div className="align-content-center">
  //         <img src={request.profilePic} alt="Profile" />
  //       </div>
  //       <div className="request-details ms-3">
  //         <div className="text-start fw-bold"> {request.name}</div>
  //         <div className="text-start">Blood units: {request.units}</div>
  //         <div className="text-start"> {request.date}</div>
  //         <div className="text-start"> {request.Address}</div>
  //       </div>
  //       <div className="blood-group ms-auto">
  //         <img src={request.bloodGroupImage} alt="Blood Group" />
  //       </div>
  //       <div className="icon-container d-flex me-3">
  //         <Link to="#" className="share-link me-2">
  //           <img src={shareIcon} alt="Share" className="icon-img" />
  //         </Link>
  //         <Link to="#" className="location-link">
  //           <img src={locationIcon} alt="Location" className="icon-img" />
  //         </Link>
  //       </div>
  //     </div>
  //   </div>
  // );

  const renderRequestCard = (request, showAcceptButton) => (
    <div
      className="request-card"
      key={request?.id}
      onClick={() => handleCardClick(request)}
    >
      <div className="request-header d-flex align-items-center">
        <div className="align-content-center">
          <img src={profPicImg} alt="Profile" />
          {/* Profile Picture Placeholder */}
        </div>
        <div className="request-details ms-3">
          <div className="text-start fw-bold">
            {request?.attender_first_name} {request?.attender_last_name}
          </div>
          <div className="text-start">{request?.location}</div>
          <div className="text-start">
            Blood units: {request?.quantity_units}
          </div>
          <div className="text-start">
            {request?.required_date?.split("T")[0]}
          </div>
        </div>
        <div className="blood-group ms-auto">
          <img src={bloodGroupImg} alt="Blood Group" />
          {/* Blood Group Placeholder */}
        </div>
      </div>

      <div className="accept-donar-button d-flex align-items-center mt-3">
        <div className="icon-container d-flex me-3">
          <Link to="#" className="share-link me-2">
            <img src={shareIcon} alt="Share" className="icon-img" />
          </Link>
          <Link to="#" className="location-link">
            <img src={locationIcon} alt="Location" className="icon-img" />
          </Link>
        </div>
        {showAcceptButton && (
          <button className="accepted-donors-btn btn btn-primary">
            Accept
          </button>
        )}
      </div>
    </div>
  );

  const renderOthersCard = (request) => (
    <div className="request-card" key={request?.id}>
      <div className="request-header d-flex align-items-center">
        <div className="align-content-center">
          <img src={profPicImg} alt="Profile" />
        </div>
        <div className="request-details ms-3">
          <div className="text-start fw-bold">
            {request?.attender_first_name}
          </div>
          <div className="text-start">
            Blood units: {request?.quantity_units}
          </div>
          <div className="text-start">
            {request?.required_date.split("T")[0]}
          </div>
          <div className="text-start"> {request?.location}</div>
        </div>
        <div className="blood-group ms-auto">
          <img src={bloodGroupImg} alt="Blood Group" />
        </div>
        <div className="icon-container d-flex me-3">
          <Link to="#" className="share-link me-2">
            <img src={shareIcon} alt="Share" className="icon-img" />
          </Link>
          <Link to="#" className="location-link">
            <img src={locationIcon} alt="Location" className="icon-img" />
          </Link>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <h3 className="mt-3">Donate Blood</h3>
      <div className="blood-request-container">
        <div className="tabs mt-4">
          <button
            className={`tab ${activeTab === "open" ? "active" : ""}`}
            onClick={() => setActiveTab("open")}
          >
            Matching request ({openRequests.length})
          </button>
          <button
            className={`tab ${activeTab === "closed" ? "active" : ""}`}
            onClick={() => setActiveTab("closed")}
          >
            Other request ({closedRequests.length})
          </button>
        </div>
        <div className="requests mb-5">
          {activeTab === "open" &&
            openRequests.map((request) => renderRequestCard(request, true))}
          {activeTab === "closed" &&
            closedRequests.map((request) => renderOthersCard(request, false))}
        </div>
        <div>
          {activeTab === "open" && openRequests.length === 0 && (
            <h4 className="mx-auto mb-5">No matching requests available.</h4>
          )}
          {activeTab === "closed" && closedRequests.length === 0 && (
            <h4 className="mx-auto mb-5">No Data available.</h4>
          )}
        </div>
      </div>
    </>
  );
}

export default Donate;
