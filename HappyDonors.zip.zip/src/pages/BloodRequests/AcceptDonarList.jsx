import "../../css/BloodRequest.css";
import bloodGroupImg from "../../assets/bloodimage.png";
import profPicImg from "../../assets/profpic.png";
import { useNavigate } from "react-router";

const AcceptDonorList = () => {
  const navigate = useNavigate();

  const openRequests = [
    {
      id: 12345,
      name: "sheeraz",
      date: "2024-07-16",
      location: "General Hospital,Barracks",
      address: "Nehru Street, Pondicherry",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
    {
      id: 12345,
      name: "aabid",
      date: "2024-07-16",
      location: "General Hospital,Barracks",
      address: "Nehru Street, Pondicherry",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
    {
      id: 12345,
      name: "shariq",
      date: "2024-07-16",
      location: "General Hospital,Barracks",
      address: "Nehru Street, Pondicherry",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
  ];

  const renderRequestCard = (request) => (
    <div className="request-card" key={request.id}>
      <div className="request-header">
        <div className="align-content-center">
          <img src={request.profilePic} alt="Profile" />
        </div>
        <div className="request-details">
          <div className="request-id">Name: {request.name}</div>
          <div className="request-date">Location: {request.location}</div>
          <div className="request-address">Address: {request.address}</div>
          <div className="request-units">Date: {request.date}</div>
        </div>
        <div className="blood-group">
          <img src={request.bloodGroupImage} alt="Blood Group" />
        </div>
      </div>

      <div className="accept-donar-button justify-content-end">
        <button
          className="accepted-donors-btn"
          onClick={() => navigate("/confirmdonation")}
        >
          Mark As Donated
        </button>
      </div>
    </div>
  );

  return (
    <>
      <h3 className="mt-3">Accepted Donors</h3>
      <div className="blood-request-container">
        <div className="requests mb-5 mt-5">
          {openRequests.map(renderRequestCard)}
        </div>
      </div>
    </>
  );
};

export default AcceptDonorList;
