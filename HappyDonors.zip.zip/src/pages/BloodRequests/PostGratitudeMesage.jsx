import { useState } from "react";
import uploadIcon from "../../assets/image-upload.png";
import micIcon from "../../assets/Microphone.png";
import calendarIcon from "../../assets/Clapperboard.png";

export default function PostGratitudeMesage() {
  const [image, setImage] = useState(null);
  const [transcript, setTranscript] = useState("");
  const [isRecording, setIsRecording] = useState(false);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setImage(URL.createObjectURL(file));
    }
  };

  const handleMicClick = () => {
    if (!window.webkitSpeechRecognition) {
      alert("Speech recognition is not supported in your browser.");
      return;
    }

    const recognition = new window.webkitSpeechRecognition();
    recognition.continuous = false; // Set to true if you want to keep recognizing speech
    recognition.interimResults = false; // Set to true to get interim results

    recognition.onstart = () => {
      setIsRecording(true);
    };

    recognition.onresult = (event) => {
      const speechToText = event.results[0][0].transcript;
      setTranscript(speechToText);
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognition.onerror = (event) => {
      console.error("Speech recognition error", event.error);
      setIsRecording(false);
    };

    recognition.start();
  };

  const handleCalendarClick = () => {
    alert("Calendar button clicked");
  };

  return (
    <div>
      <h2 className="mt-4">PostGratitudeMesage</h2>
      <div
        className="card col-lg-8 col-md-8  col-sm-8 mx-auto align-items-start mt-5 mb-5 gap-3"
        style={{ color: "#097E14" }}
      >
        <div className="">Name:</div>
        <div>Request ID:</div>
        <div>Blood Type:</div>
        <div>Quantity Needed:</div>
        <div>Location:</div>
      </div>
      <h5
        style={{ color: "blue" }}
        className="col-lg-8 col-md-8  col-sm-8 mx-auto text-start"
      >
        Dear Donors,
      </h5>

      <div className="col-lg-7 col-md-8 mx-auto mt-4">
        <div className="border p-3 rounded shadow-sm bg-white">
          <p className="text-center text-muted mb-4">
            Thank you for your donation!
            <br />
            Your generosity has saved lives.
          </p>
          <div
            style={{ borderBottom: "1px solid #ccc" }}
            className="mb-3"
          ></div>
          <div className="d-flex justify-content-end mb-3 mt-3">
            {/* File Upload Icon */}
            <label htmlFor="file-upload" className="me-3">
              <img
                src={uploadIcon}
                alt="Upload Icon"
                className="icon"
                style={{ cursor: "pointer" }}
              />
            </label>
            <input
              id="file-upload"
              type="file"
              accept="image/*"
              style={{ display: "none" }}
              onChange={handleImageUpload}
            />
            {/* Mic Icon */}
            <img
              src={micIcon}
              alt="Microphone Icon"
              className="icon me-3"
              style={{ cursor: "pointer" }}
              onClick={handleMicClick}
            />
            {/* Calendar Icon */}
            <img
              src={calendarIcon}
              alt="Calendar Icon"
              className="icon"
              style={{ cursor: "pointer" }}
              onClick={handleCalendarClick}
            />
          </div>
          {isRecording && (
            <p className="text-center text-danger">Recording...</p>
          )}
          {transcript && (
            <div className="text-center mt-3">
              <p className="transcript">{transcript}</p>
            </div>
          )}
          {image && (
            <div className="text-center mt-3">
              <img
                src={image}
                alt="Uploaded Preview"
                className="img-fluid rounded"
              />
            </div>
          )}
        </div>
      </div>

      <div className="col-lg-6 col-md-8 col-sm-10 mx-auto mt-5 mb-5 d-flex">
        <button
          className="btn  flex-fill me-2 fw-bold"
          style={{ padding: "20px", background: "#D9D9D9", color: "gray" }}
        >
          Cancel
        </button>
        <button
          className="btn btn-primary flex-fill ms-2 fw-bold"
          style={{ padding: "20px" }}
        >
          Submit
        </button>
      </div>
    </div>
  );
}
