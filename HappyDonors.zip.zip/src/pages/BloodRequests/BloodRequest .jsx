import { useEffect, useState } from "react";
import "../../css/BloodRequest.css";
import bloodGroupImg from "../../assets/bloodgroup.png";
import profPicImg from "../../assets/profpic.png";
import { useNavigate } from "react-router";

const BloodRequest = () => {
  const [activeTab, setActiveTab] = useState("open");
  const navigate = useNavigate();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const openRequests = [
    {
      id: 12345,
      date: "2024-07-16",
      units: 2,
      address: "Nehru Street, Pondicherry",
      status: "Initiated",
      //   profilePic: require("../assets/bloodgroup.png"),
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
    {
      id: 45645,
      date: "2024-07-16",
      units: 2,
      address: "Nehru Street, Pondicherry",
      status: "Initiated",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
    {
      id: 34512,
      date: "2024-07-16",
      units: 3,
      address: "Nehru Street, Pondicherry",
      status: "Initiated",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
    {
      id: 15455,
      date: "2024-07-16",
      units: 1,
      address: "Nehru Street, Pondicherry",
      status: "Initiated",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
  ];

  const closedRequests = [
    {
      id: 67890,
      date: "2024-07-16",
      units: 1,
      address: "Nehru Street, Pondicherry",
      status: "Closed",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
    {
      id: 91234,
      date: "2024-07-16",
      units: 4,
      address: "Nehru Street, Pondicherry",
      status: "Closed",
      profilePic: profPicImg,
      bloodGroupImage: bloodGroupImg,
    },
  ];

  const handleCardClick = () => {
    navigate("/donarlist");
  };

  const renderRequestCard = (request) => (
    <div
      className="request-card"
      key={request.id}
      onClick={() => handleCardClick(request)}
    >
      <div className="request-header">
        <div className="align-content-center">
          <img src={request.profilePic} alt="Profile" />
        </div>
        <div className="request-details">
          <div className="request-id">Request ID: {request.id}</div>
          <div className="request-date">Date: {request.date}</div>
          <div className="request-units">Units Required: {request.units}</div>
          <div className="request-address">Address: {request.address}</div>
          {/* <div className="request-status">Status: {request.status}</div> */}
        </div>
        <div className="blood-group">
          <img src={request.bloodGroupImage} alt="Blood Group" />
        </div>
      </div>
      {/* <div className="request-details">
        <div className="request-id">Request ID: {request.id}</div>
        <div className="request-date">Date: {request.date}</div>
        <div className="request-units">Units Required: {request.units}</div>
        <div className="request-address">Address: {request.address}</div>
      </div> */}
      <div className="accept-donar-button justify-content-end">
        <button className="accepted-donors-btn">Accepted Donors</button>
      </div>
    </div>
  );

  return (
    <>
      <h3 className="mt-3">My Requests</h3>
      <div className="blood-request-container">
        <div className="tabs mt-4">
          <button
            className={`tab ${activeTab === "open" ? "active" : ""}`}
            onClick={() => setActiveTab("open")}
          >
            Open ({openRequests.length})
          </button>
          <button
            className={`tab ${activeTab === "closed" ? "active" : ""}`}
            onClick={() => setActiveTab("closed")}
          >
            Closed ({closedRequests.length})
          </button>
        </div>
        <div className="requests mb-5 mt-5">
          {activeTab === "open" && openRequests.map(renderRequestCard)}
          {activeTab === "closed" && closedRequests.map(renderRequestCard)}
        </div>
      </div>
    </>
  );
};

export default BloodRequest;
